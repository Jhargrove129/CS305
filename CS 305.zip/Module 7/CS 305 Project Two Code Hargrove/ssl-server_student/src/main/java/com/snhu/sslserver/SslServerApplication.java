package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ChecksumController {

    private static final String USER_NAME = "Jason Hargrove";
    private static final String DATA = USER_NAME + " - Secure Software Practices Unique Hash String 2025";

    @GetMapping(value = "/hash", produces = "text/html")
    public String generateChecksum() {
        String checksum = calculateSHA256(DATA);
        return "<html><body>" +
                "<h2>Checksum Verification</h2>" +
                "<p><strong>Name:</strong> " + USER_NAME + "</p>" +
                "<p><strong>Data:</strong> " + DATA + "</p>" +
                "<p><strong>SHA-256 Checksum:</strong> " + checksum + "</p>" +
                "</body></html>";
    }


    private String calculateSHA256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(encodedHash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 Algorithm not available", e);
        }
    }

    private String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            hexString.append(String.format("%02x", b));
        }
        return hexString.toString();
    }
}
